import java.util.*;

//la classe biblioteca implementa l'interfaccia Iterable (di string
// poiché navigheremo su una lista di stringhe)
class Biblioteca implements Iterable<String> {
    private List<String> libri;

    // Se avessi voluto navigare sula lista di libri in avanti e indietro allora
    // avrei dovuto
    // implementare una doubly linked list a mano
    // (https://www.softwaretestinghelp.com/doubly-linked-list-in-java/)

    public Biblioteca() {
        libri = new LinkedList<>();
    }

    public void addLibro(String s) {
        libri.add(s);
    }

    // Questo è il metodo che torna l'iteratore
    // l'iteratore è un oggetto che consente di navigare sulla biblioteca
    // e, nello specifico, sulla lista dei libri
    public Iterator<String> iterator() {
        return new BibIterator();
    }

    // la dichiaro direttamente dentro la classe biblioteca poiché serve solo qui
    private class BibIterator implements Iterator<String> {

        // su una lista non posso andare al successivo (le liste di Java non
        // hanno metodi next o prec)
        // converto in array in modo da iterare tramite indice
        // Convertire una lista di stringhe in array di stringhe!!!
        private String[] elenco;
        private int index;
        private int eliminati;

        public BibIterator() {
            elenco = libri.toArray(new String[0]);
            index = 0;
            eliminati = 0;
        }

        public boolean hasNext() {
            return index < elenco.length;
        }

        public String next() {
            if (hasNext()) {
                return elenco[index++];
            }
            throw new java.util.NoSuchElementException();
        }

        public void remove() {
            // rimuove l'elemento corrente (dalla lista e non dal vettore)
            if ((index - eliminati) > 0) {
                libri.remove(index - eliminati - 1);
                eliminati++;
            } else {
                throw new UnsupportedOperationException();
            }
        }
    }
}

// Classe che genera numeri pseudocasuali ma proprio poco poco poco casuali
class Pseudo {
    int seed;
    final int a = 123121;
    final int b = 986517;
    int x;

    Pseudo() {
        seed = (int) System.nanoTime();
        x = seed;
    }

    Pseudo(int v) {
        seed = v;
        x = seed;
    }

    int next() {
        long ret = (long) a * (long) x + (long) b;
        x = (int) (ret % Integer.MAX_VALUE);
        return x;
    }
}

public class App {
    public static void main(String[] args) throws Exception {

        List<Integer> li = new LinkedList<>();

        // UN esempio di generatore di numeri pseudocasuali è
        // Xi+1 = a*Xi+b
        Random rnd = new Random(12763); // System.nanoTime());
        for (int i = 0; i < 10; i++) {
            li.add(rnd.nextInt(0, 10000));
        }

        System.out.println(li);

        // Proviamo i generatore di numeri pseudocasuali
        Pseudo p = new Pseudo(1);
        for (int i = 0; i < 100; i++) {
            System.out.println(p.next());
        }

        // Torniamo a noi, come possiamo scandire la lista li?
        // possiamo eliminare dalla lista li tutti i valori maggiori di 1000?

        // Modo più immediato ma che non mi fa modificare la lista
        for (int x : li) {
            System.out.println(x);
        }

        // Modo molto più lento e complesso per leggere e modificare la lista
        for (int i = 0; i < li.size(); i++) {
            System.out.println(li.get(i));
            // ogni volta devo accedere all'elemento i-esimo della lista
            // quindi se la lista è lunga N, allora
            // al termine avrò effettuato N*N operazioni
            // Non è feasibile/utilizzabile
        }

        // uso un iteratore sulla lista
        System.out.println("\n\nIteratore sulla lista");

        // lista di interi => iteratore di interi
        Iterator<Integer> lit = li.iterator();
        while (lit.hasNext()) {
            int v = lit.next();
            System.out.println(v);
            if (v > 1000) {
                lit.remove();
            }
        }
        System.out.println(li);

        // come al solito ci poniamo un problema
        // Supponiamo di avere una classe che contiene una lista
        // Esempio la classe biblioteca che contiene una lista di libri

        // creiamo la biblioteca e agggiungiamo qualche libro
        Biblioteca bib = new Biblioteca();
        bib.addLibro("L'isola del tesoro");
        bib.addLibro("1");
        bib.addLibro("L'isola misteriosa");
        bib.addLibro("1");
        bib.addLibro("Il giro del mondo in 80 giorni");
        bib.addLibro("I pirati di Monpracen");
        bib.addLibro("1");
        bib.addLibro("Ventimila leghe sotto i mari");
        bib.addLibro("1");
        bib.addLibro("Cuore");
        bib.addLibro("1");

        // Voglio stampare tutti i libri della biblioteca!!!!
        // Se l'attributo libri della biblioteca è Private
        // non posso stampare
        // System.out.println(bib.libri);

        // Ma potrei utilizzare l'interfaccia Iterator e associarla alla biblioteca
        // Cioè potrei implementare un iteratore dentro la biblioteca
        // bib contiene una lista di stringhe => iteratore di stringhe
        Iterator<String> is = bib.iterator();

        while (is.hasNext()) {
            var v = is.next();
            if (v.length() == 1) {
                is.remove();
            }
            // System.out.println(v);
        }

        // Ora stampo la lista
        is = bib.iterator();

        while (is.hasNext()) {
            var v = is.next();
            System.out.println(v);
        }
    }
}
