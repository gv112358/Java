import java.util.*;

class Persona {
    String nome;
    String cognome;
    int eta;

    public Persona(String n, String c, int e) {
        nome = n;
        cognome = c;
        eta = e;
    }

    int getEta() {
        return eta;
    }

    public String toString() {
        return String.format("%s, %s, %d", nome, cognome, eta);
    }
}

public class App {

    public static void main(String[] args) throws Exception {

        List<Integer> li = new LinkedList<>();
        li.addAll(Arrays.asList(new Integer[] { 5, 6, 8, 7, 9, 1 }));

        // Ordinamento della lista
        // ordinare N elementi richiede c*N*log(N) operazioni
        // dove il log è in base 2
        // dove c è una costante >=1
        System.out.println(li.toString());
        Collections.sort(li);
        System.out.println(li.toString());
        // !!Collections.sort !!!modifica!!! la lista (la collezione)
        // E come fa?
        for (Integer x : li) {
            // ..
            // potete utilizzare i valori contenuti nella lista ma non potete modificarli!!!
        }

        // Creo una lista di persone
        List<Persona> lp = new LinkedList<>();
        lp.add(new Persona("Mario", "Rossi", 24));
        lp.add(new Persona("Paolo", "Bianchi", 25));
        lp.add(new Persona("Giuseppe", "Verdi", 21));
        lp.add(new Persona("Antonio", "Turchese", 19));
        lp.add(new Persona("Giuseppe", "Verdi", 89));
        lp.add(new Persona("Giuseppe", "Verdi", 24));
        lp.add(new Persona("Giuseppe", "Rossi", 24));

        Collections.sort(lp, Comparator.comparingInt(Persona::getEta));

        lp.sort(Comparator.comparingInt(Persona::getEta));

        // Come posso stampare un oggetto della mia classe utilizzando il metodo
        // System.out.println??
        // Risposta => aggiungendo un metodo toString alla classe

        // Esempio: supponiamo che la classe Persona non abbia un metodo toString
        System.out.println(new Persona("n", "c", 10));
        // La println chiamerà il metodo toString di Persona.
        // Ma persona non ha tale metodo, quindi viene chiamato il metodo della sua
        // superclasse (Object)
        Persona p = new Persona("n", "c", 10);
        p.toString();

        // Se, invece, implemento un metodo toString nella classe persona allora la
        // println richiamerà tale metodo

        System.out.println(lp.toString());

        // Come posso ordinare rispetto al nome o al cognome?
        // devo passare al Comparatore una funzione/metodo di compare/confronto
        Comparator<Persona> comp = new Comparator<>() {
            public int compare(Persona p1, Persona p2) {
                // deve tornare
                // -1 se p1 < p2
                // +1 se p1 > p2
                // 0 se p1 == p2

                // // ordiniamo rispetto a nome
                // return p1.nome.compareTo(p2.nome);

                // // ordiniamo rispetto a cognome
                // return p1.cognome.compareTo(p2.cognome);

                // // ordiniamo rispetto alla lunghezza complessiva di nome+cognome
                // return (p1.nome + p1.cognome).length() - (p2.nome + p2.cognome).length();

                // ordiniamo rispetto a nome, cognome ed età?
                int inome = p1.nome.compareTo(p2.nome);
                int icognome = p1.cognome.compareTo(p2.cognome);
                int ieta = p1.eta - p2.eta;
                if (inome < 0) {
                    return -1;
                }
                if (inome > 0) {
                    return 1;
                }
                if (icognome < 0) {
                    return -1;
                }
                if (icognome > 0) {
                    return 1;
                }
                return ieta;

            }
        };
        lp.sort(comp);
        System.out.println(lp.toString());

        // In analogia a quanto visto, vale anche la...
        Collections.sort(lp, comp);

    }
}
